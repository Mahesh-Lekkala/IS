package com.company;

public class Test {
    public static void main(String[] args) throws Exception {
        Util.printMat(Util.stringToMatrix("123480765"));
    }
}
