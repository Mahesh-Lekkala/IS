package com.company;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class State {
    private int[] qRow;
    private int cost;

    public State(int[] qRow){
        this.qRow=qRow;
        this.cost=calculateStateCost(qRow);
    }

    private int calculateStateCost(int[] qRow) {
        int cost=0;

        for(int i=0;i<qRow.length;i++){

            for(int j=i+1;j<qRow.length;j++){
                if(qRow[i]==qRow[j] || i==j)
                    cost++;
                else if(Math.abs(i-j)==Math.abs(qRow[i]-qRow[j]))
                    cost++;
            }
        }
        return cost;
    }

    public int[] getqRow() {
        return qRow;
    }
    public int getCost() {
        return cost;
    }
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < qRow.length; i++) {
            for (int j = 0; j < qRow.length; j++) {
                if (qRow[i] == j) {
                    sb.append('Q');
                } else {
                    sb.append('.');
                }

                sb.append(' ');
            }

            sb.append('\n');
        }

        sb.deleteCharAt(sb.length() - 1);
        return sb.toString();
    }

    public ArrayList<State> generateSuccessors() {
        int originalValue;
        int[] copy;
        int[] board = Arrays.copyOf(qRow, qRow.length);
        ArrayList<State> successors = new ArrayList<>((qRow.length * qRow.length) - qRow.length);
        for (int i = 0; i < board.length; i++) {
            originalValue = board[i];
            for (int j = 0; j < board.length; j++) {
                if (j == originalValue) {
                    continue;
                }

                board[i] = j;
                copy = Arrays.copyOf(board, board.length);
                successors.add(new State(copy));
            }

            board[i] = originalValue;
        }

        if (successors.size() != (qRow.length * qRow.length) - qRow.length) {
            System.out.println("PROBLEM!!!!");
        }

        Collections.sort(successors, (State s1, State s2) -> {
            return s1.cost - s2.cost;
        });

        return successors;
    }
}
