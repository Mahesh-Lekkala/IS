package com.company;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Main {
    int resetSum=0;
    int randomGenerateSum=0;
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Main mainObj = new Main();
        System.out.println("Enter number of Queens in n-Queen Problem :");
        int numOfQueens = scanner.nextInt();
        while(numOfQueens<4){
            System.out.println("Invalid number of Queens. Please provide number greater than equal to 4");
            numOfQueens = scanner.nextInt();
        }
        System.out.println("Provide RunTime: ");
        int maxRun = scanner.nextInt();
        while(maxRun<=0){
            System.out.println("MaxRun should be greater than 0");
            maxRun = scanner.nextInt();
        }
        int choice=0;
        do {
            System.out.println("Choose Search Type\n1.Hill Climbing Search\n2.Hill-climbing search with sideways move");
            System.out.println("3.Random-restart hill-climbing search without sideway moves");
            System.out.println("4.Random-restart hill-climbing search with sideway moves");
            System.out.println("5.Exit");
            choice = scanner.nextInt();
            if(choice<1 ||choice>5){
                System.out.println("Invalid choice: Please choose from provided options");
                choice = scanner.nextInt();
            }
            if(choice==5)
                System.exit(0);

            int sucessCount = 0;
            int successStepCount = 0;
            int failureCount = 0;
            int failureStepCount = 0;
            int randomOutput = 0;

            if (choice == 1)
                System.out.println("------------------Hill Climbing Search-----------------------------");
            else if (choice == 2)
                System.out.println("---------------Hill-climbing search with sideways move--------------");
            else if (choice == 3)
                System.out.println("-----------------Random-restart hill-climbing search without sideway moves----------------");
            else if (choice == 4)
                System.out.println("-----------------Random-restart hill-climbing search with sideway moves----------------");


            for (int i = 0; i < maxRun; i++) {
                ArrayList<State> path = null;
                State initialState = mainObj.generateRandomState(numOfQueens);
                switch (choice) {
                    case 1:
                        path = mainObj.performHillClimbingSearch(initialState);
                        break;
                    case 2:
                        path = mainObj.performHillClimbingSearchWithSidewayMove(initialState);
                        break;
                    case 3:
                        path = mainObj.performHillClimbingSearchRandomRestartWithoutSidewayMoves(initialState);
                        break;
                    case 4:
                        path = mainObj.performHillClimbingSearchRandomRestartWithSidewayMoves(initialState);
                        break;
                    default:
                }
                State lastState = path.get(path.size() - 1);
                if (lastState.getCost() == 0) {
                    sucessCount++;
                    successStepCount += path.size();
                    if (randomOutput < 4) {
                        System.out.println("The search sequences (" + (randomOutput + 1) + ") :");
                        System.out.println("Path cost: " + path.size());
                        printPath(path);
                        randomOutput++;
                    }

                } else {
                    failureCount++;
                    failureStepCount += path.size();
                }
            }

            System.out.println("success count " + sucessCount);
            System.out.println("success rate " + ((double) sucessCount / maxRun) * 100 + " %");
            System.out.println("failure count " + failureCount);
            System.out.println("failure rate " + ((double) failureCount / maxRun) * 100 + " %");
            System.out.println("Average no. of Steps when success: " + (double) successStepCount / sucessCount);
            if (failureCount != 0)
                System.out.println("Average no. of Steps when failure: " + (double) failureStepCount / failureCount);
            else
                System.out.println("Average no. of Steps when failure: 0");
            if (choice == 3 || choice == 4) {
                System.out.println("total reset count : " + mainObj.resetSum);
                System.out.println("Avg reset count : " + (double) mainObj.resetSum / (maxRun + mainObj.randomGenerateSum));
            }
        }while(choice != 5);

    }

    private ArrayList<State> performHillClimbingSearchRandomRestartWithSidewayMoves(State initialState) {
        ArrayList<State> path = new ArrayList<>();
        Random randomPosition= new Random();
        path.add(initialState);
        int reset=0;
        int sameCostCounter=0;
        State neighbour = null;
        State current = new State(initialState.getqRow());
        ArrayList<State> neighboursList = null;
        while (true) {
            if (current.getCost() == 0) {
                resetSum +=reset;
                return path;
            }
            neighboursList = current.generateSuccessors();
            //searchCost += neighbors.size();
            if(current.getCost()==neighboursList.get(0).getCost()){
                sameCostCounter=0;
                int index=0;
                while(current.getCost()==neighboursList.get(index).getCost()) {
                    sameCostCounter++;
                    index++;
                }
                neighbour=neighboursList.get(randomPosition.nextInt(sameCostCounter));
            }
            else
            neighbour = neighboursList.get(0);

            /*if (current.getCost() < neighbour.getCost()) {
                //System.out.println("*********resetCount : "+reset);
                return path;
            } else */
                if(current.getCost()<=neighbour.getCost()){
                //System.out.println("no better state found. Resetting the state");
                current=generateRandomState(initialState.getqRow().length);
                path.clear();
                path.add(current);
                reset++;
                    randomGenerateSum++;
            } else {
                current = neighbour;
                path.add(neighbour);
            }
        }
    }

    private ArrayList<State> performHillClimbingSearchRandomRestartWithoutSidewayMoves(State initialState) {
        ArrayList<State> path = new ArrayList<>();
        path.add(initialState);
        int reset=0;
        State neighbour = null;
        State current = new State(initialState.getqRow());
        ArrayList<State> neighboursList = null;
        while (true) {
            if (current.getCost() == 0) {
                resetSum +=reset;
                return path;
            }

            neighboursList = current.generateSuccessors();
            //searchCost += neighbors.size();

            neighbour = neighboursList.get(0);

            /*if (current.getCost() < neighbour.getCost()) {
                System.out.println("*********resetCount : "+reset);
                return path;
            } else
                */
                if(current.getCost()<=neighbour.getCost()){
                //System.out.println("no better state found. Resetting the state");
                current=generateRandomState(initialState.getqRow().length);
                path.clear();
                path.add(current);
                reset++;
            } else {
                current = neighbour;
                path.add(neighbour);
            }
        }
    }

    private ArrayList<State> performHillClimbingSearchWithSidewayMove(State initialState) {
        Random randomPosition = new Random();
        ArrayList<State> path = new ArrayList<>();
        int sideWayMovesCounter=100;
        ArrayList<State> neighboursList = null;
        State neighbour = null;
        int sameCostCounter=0;
        path.add(initialState);

        State current = new State(initialState.getqRow());
        while (true) {
            if (current.getCost() == 0) {
                return path;
            }

            neighboursList = current.generateSuccessors();
            //searchCost += neighbors.size();
            if(current.getCost()==neighboursList.get(0).getCost()){
                sameCostCounter=0;
                int index=0;
                while(current.getCost()==neighboursList.get(index).getCost()) {
                    sameCostCounter++;
                    index++;
                }
                neighbour=neighboursList.get(randomPosition.nextInt(sameCostCounter));
            }
            else
            neighbour = neighboursList.get(0);

            if (current.getCost() < neighbour.getCost()) {
                return path;
            }
            if(current.getCost()==neighbour.getCost()){
                sideWayMovesCounter--;
                if(sideWayMovesCounter<=0)
                    return path;
            } else{
                sideWayMovesCounter=100;
            }
            current = neighbour;
            path.add(neighbour);
        }
    }

    private static void printPath(ArrayList<State> path) {

        for(State state : path){
            System.out.println(state);
            System.out.println("cost : "+state.getCost());
            System.out.println();
        }

    }

    private ArrayList<State> performHillClimbingSearch(State initialState) {
        ArrayList<State> neighboursList = null;
        State neighbour = null;
        ArrayList<State> path = new ArrayList<>();
        path.add(initialState);

        State current = new State(initialState.getqRow());
        while (true) {
            if (current.getCost() == 0) {
                return path;
            }

            neighboursList = current.generateSuccessors();
            //searchCost += neighbors.size();
            neighbour = neighboursList.get(0);
            if (current.getCost() <= neighbour.getCost()) {
                return path;
            }
            current = neighbour;
            path.add(neighbour);
        }

    }

    private State generateRandomState(int noOfQueens) {
        //State randomState = new State(noOfQueens);
        int[] qRow = new int[noOfQueens];
        Random randomPosition = new Random();
        for (int i = 0; i < noOfQueens; i++) {
            qRow[i] = randomPosition.nextInt(noOfQueens);
        }
        return new State(qRow);
    }
}
